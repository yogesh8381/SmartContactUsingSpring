package com.contactMangement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import com.contactMangement.model.User;
import com.contactMangement.model.UserContact;

@Component
public interface ContactService {
	
	public  Page<UserContact> findContact(int userId, Pageable pageable);
	
	public Optional<UserContact> showContactUsingContactId(int contactId);
	
	/*
	 * public Optional<UserContact> deleteContact(int contactId);
	 */
	
	public UserContact findByContactNameContainingAndUser(String contactName, User user);
}
