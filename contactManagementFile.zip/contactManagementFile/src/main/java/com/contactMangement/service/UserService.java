package com.contactMangement.service;

import org.springframework.stereotype.Component;

import com.contactMangement.model.User;

@Component
public interface UserService {
	User createUser(User user);
	
	public User getUserByUserName(String email);

}
