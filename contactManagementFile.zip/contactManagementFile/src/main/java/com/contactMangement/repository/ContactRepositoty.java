package com.contactMangement.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.contactMangement.model.User;
import com.contactMangement.model.UserContact;


public interface ContactRepositoty extends JpaRepository<UserContact, Integer> {
	
	@Query("from UserContact as c where c.user.userId=:userId ")
	public Page<UserContact> findContactByUser(@Param("userId")int userId, Pageable pageable);
	
	
	//searching purpose
	public List<UserContact> findByContactNameContainingAndUser(String contactName, User user);

	
	
	
	

}
