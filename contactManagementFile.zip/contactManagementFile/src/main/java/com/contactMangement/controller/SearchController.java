package com.contactMangement.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.contactMangement.model.User;
import com.contactMangement.model.UserContact;
import com.contactMangement.repository.ContactRepositoty;
import com.contactMangement.repository.UserRepository;
import com.contactMangement.service.UserService;

@RestController
public class SearchController {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private UserService userService;

	@Autowired
	private ContactRepositoty contactRepository;

	@Autowired
	private com.contactMangement.service.ContactService contactService;

	@GetMapping("/search/{query}")
	public ResponseEntity<?> searchContact(@PathVariable("query") String query, Principal principal) {
		User user = this.userService.getUserByUserName(principal.getName());
		List<UserContact> userContact =  this.contactRepository.findByContactNameContainingAndUser(query, user);
		 return ResponseEntity.ok(userContact);

	}

}
