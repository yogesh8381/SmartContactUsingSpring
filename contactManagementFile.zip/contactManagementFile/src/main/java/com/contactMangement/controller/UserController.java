package com.contactMangement.controller;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.contactMangement.message.UserMessage;
import com.contactMangement.model.User;
import com.contactMangement.model.UserContact;
import com.contactMangement.repository.ContactRepositoty;
import com.contactMangement.repository.UserRepository;
import com.contactMangement.service.ContactService;
import com.contactMangement.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private BCryptPasswordEncoder  bCryptPasswordEncoder;
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserService userService;

	@Autowired
	private ContactService contactService;

	@Autowired
	private ContactRepositoty contactRepositoty;

	// adding commomn data to response
	@ModelAttribute
	public void addCommonData(Model model, Principal principal) {

		String userName = principal.getName();
		User user = userService.getUserByUserName(userName);
		System.out.println(user);
		model.addAttribute("user", user);

	}

	@RequestMapping("/index")
	public String dashBoard(Model model, Principal principal) {
		model.addAttribute("title", "Home Page");

		return "Normal/user_dashboard";
	}

	// open form

	@GetMapping("/add_contact")
	public String openAddContactForm(Model model) {
		model.addAttribute("title", "add contact");
		model.addAttribute("contact", new UserContact());

		return "Normal/add_contact_form";
	}

	// proceesing add contact form
	@PostMapping("/process_contact")
	public String contactProcess(@ModelAttribute UserContact contact, Model model, HttpSession session,
			Principal principal) {
		try {
			System.out.println(contact);

			String name = principal.getName();
			User user = this.userService.getUserByUserName(name);

			/*
			 * //processing and uploadig file if(file.isEmpty()) {
			 * System.out.println("file is empty");
			 * 
			 * } else { //upload file to folder
			 * contact.setContactPersonImage(file.getOriginalFilename()); File saveFile=new
			 * ClassPathResource("static/img").getFile(); Path path=
			 * Paths.get(saveFile.getAbsolutePath()+File.separator+file.getOriginalFilename(
			 * ));
			 * 
			 * Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
			 * }
			 */

			contact.setUser(user);

			user.getContacts().add(contact);
			this.userRepository.save(user);

			// meassage success..
			session.setAttribute("message",
					new UserMessage("Your contact is added succesfully!! Add more..", "success"));

		} catch (Exception e) {
			System.out.println("ERROR" + e.getMessage());
			session.setAttribute("message", new UserMessage("Something went wrong!! Try Again..", "danger"));

		}

		return "Normal/add_contact_form";

	}

	// show all contact handler
	@GetMapping("/show_contacts/{page}")
	public String showContacts(@PathVariable("page") Integer page, Model model, Principal principal) {
		model.addAttribute("title", "Show User Contacts");

		String userName = principal.getName();
		User user = this.userService.getUserByUserName(userName);

		Pageable pageable = PageRequest.of(page, 5);

		Page<UserContact> contacts = this.contactService.findContact(user.getUserId(), pageable);
		model.addAttribute("contacts", contacts);
		model.addAttribute("currentPage", page);
		model.addAttribute("totalPages", contacts.getTotalPages());

		return "Normal/show_contacts";
	}

	// showing perticular contact details
	@GetMapping("/{conatctId}/contact")
	public String showContactDetails(@PathVariable("conatctId") Integer conatctId, Model model, Principal principal) {
		System.out.println(conatctId);
		Optional<UserContact> contactoptinal = this.contactService.showContactUsingContactId(conatctId);
		UserContact contact = contactoptinal.get();
		//
		String userName = principal.getName();
		User user = this.userService.getUserByUserName(userName);
		if (user.getUserId() == contact.getUser().getUserId())
			model.addAttribute("contact", contact);
		model.addAttribute("title", contact.getContactName());

		return "Normal/contact_detail";

	}

	// delete contact
	@GetMapping("/delete_contact/{contactId}")
	public String deleteContact(@PathVariable("contactId") Integer contactId, Model model, HttpSession session) {
		UserContact contact = this.contactRepositoty.findById(contactId).get();

		contact.setUser(null);
		this.contactRepositoty.delete(contact);
		session.setAttribute("message", new UserMessage("Contact deleted succesfully...", "success"));

		return "redirect:/user/show_contacts/0";

	}

	// update conatct
	@PostMapping("/update-contact/{contactId}")
	public String updateForm(@PathVariable("contactId") Integer contactId, Model model) {
		model.addAttribute("title", "Update_Contact");
		UserContact contact = this.contactRepositoty.findById(contactId).get();
		model.addAttribute("contact", contact);

		return "Normal/update_form";
	}

	// update contact process
	@PostMapping("/process_update")
	public String updatecontact(@ModelAttribute UserContact contact, Model model, HttpSession session,
			Principal principal) {
		String name = principal.getName();
		User user = this.userService.getUserByUserName(name);
		contact.setUser(user);

		this.contactRepositoty.save(contact);
		session.setAttribute("message", new UserMessage("contact update succsfully...", "success"));
		return "redirect:/user/" + contact.getConatctId() + "/contact";

	}

	// your profile handler
	@GetMapping("/profile")
	public String yourProfile(Model model) {

		model.addAttribute("title", "Profile Page");

		return "Normal/profile";
	}

	@GetMapping("/settings")
	public String openSetting() {
		return "Normal/settings";
	}

	@PostMapping("/change-password")
	public String changePassword(@RequestParam("oldPassword") String oldPassword,
			@RequestParam("newPassword") String newPassword, Principal principal,HttpSession session) {
		System.out.println(oldPassword);

		String userName = principal.getName();
		User currentUser = this.userService.getUserByUserName(userName);
		
		if(this.bCryptPasswordEncoder.matches(oldPassword, currentUser.getUserPassword())) {
			//change the password
			currentUser.setUserPassword(this.bCryptPasswordEncoder.encode(newPassword));
			this.userService.createUser(currentUser);
			session.setAttribute("message", new UserMessage("Your password change succesfully","success") );
		}
		else {
			//error
			session.setAttribute("message", new UserMessage("Please enter correct old password..!!","danger") );
			return "redirect:/user/settings";		
		}
		
		return "redirect:/user/index";

	}

}
