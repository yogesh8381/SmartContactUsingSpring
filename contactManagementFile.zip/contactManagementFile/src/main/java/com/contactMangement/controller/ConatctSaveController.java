package com.contactMangement.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.contactMangement.message.UserMessage;
import com.contactMangement.model.User;

@Controller
public class ConatctSaveController {
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	@Autowired
	com.contactMangement.service.UserService UserService;
	
	@RequestMapping("/signin")
	public String login(Model model) {
		model.addAttribute("title", "Login Page");
		return "login";
	}


	@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("title", "Home-Smart Contact Manager");
		return "home";
	}

	@RequestMapping("/about")
	public String about(Model model) {
		model.addAttribute("title", "About-Smart Contact Manager");
		return "about";
	}

	@GetMapping("/signup")
	public String signUp(Model model) {
		model.addAttribute("title", "Register-Smart Contact Manager");
	    model.addAttribute("user", new User());
		return "SignUp";
	}

	// this request for registering user
	@PostMapping("/do_register")
	public String registerUser(@Valid @ModelAttribute("user") User user,BindingResult result,
			@RequestParam(value = "agreement", defaultValue = "false") boolean agreement, Model model, 
			HttpSession session) {
		try {
			if (!agreement) {
				System.out.println("You have not agree the terms and condition");
				throw new Exception("You have not agree the terms and condition");
			}
			if(result.hasErrors()) {
				System.out.println("ERROR"+result.toString());
				model.addAttribute("user", user);
				return "signUp";
				
			}
			user.setUserRole("ROLE_USER");
			user.setEnabled(true);
			user.setUserImage("default");
			user.setUserPassword(passwordEncoder.encode(user.getUserPassword()));
			User result1 = this.UserService.createUser(user);
			System.out.println(result1);

			System.out.println("Agreement" + agreement);
			System.out.println("USER" + user);

			model.addAttribute("user", new User());
			session.setAttribute("message", new UserMessage("Succesfully Register!!", "alert-success"));
			return "signUp";

		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("user", user);
			session.setAttribute("message", new UserMessage("Something went wrong!!" + e.getMessage(), "alert-danger"));
			return "signUp";
		}

	}

}
