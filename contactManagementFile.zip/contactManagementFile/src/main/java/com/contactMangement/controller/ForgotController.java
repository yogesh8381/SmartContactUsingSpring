package com.contactMangement.controller;

import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ForgotController {
	Random random = new Random(1000);
	
	@GetMapping("/forgot")
	public String oprnEmailForm() {
		return "forgot-email-form";
	}

	@PostMapping("/send-otp")
	public String sendOtp(@RequestParam("email") String email) {

		
		int otp = random.nextInt(9999999);
		System.out.println("OTP"+otp);
		return "varify_otp";
	}

}
