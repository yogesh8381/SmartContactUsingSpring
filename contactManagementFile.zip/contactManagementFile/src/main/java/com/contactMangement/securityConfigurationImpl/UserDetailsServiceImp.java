package com.contactMangement.securityConfigurationImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.contactMangement.model.User;
import com.contactMangement.repository.UserRepository;
import com.contactMangement.securityConfiguration.CustomUserDetails;

public class UserDetailsServiceImp implements UserDetailsService {
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		User user1= userRepository.getUserByUserName(username);
		if(user1==null) {
			throw new UsernameNotFoundException("could not found user");
			
		}
		CustomUserDetails customUserDetails = new CustomUserDetails(user1);
		return customUserDetails;
	}

}
