package com.contactMangement.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class UserContact {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int conatctId;
	private String contactName;
	private String nickName;
	private String work;
	private String contactPersonEmail;
	private String contactNumber;
	/*
	 * @Transient private String contactPersonImage;
	 */
	@Column(length = 100)
	private String contactDescription;
	@ManyToOne
	@JsonIgnore
	private User user;
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	public UserContact() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getConatctId() {
		return conatctId;
	}
	public void setConatctId(int conatctId) {
		this.conatctId = conatctId;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getWork() {
		return work;
	}
	public void setWork(String work) {
		this.work = work;
	}
	public String getContactPersonEmail() {
		return contactPersonEmail;
	}
	public void setContactPersonEmail(String contactPersonEmail) {
		this.contactPersonEmail = contactPersonEmail;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	/*
	 * public String getContactPersonImage() { return contactPersonImage; } public
	 * void setContactPersonImage(String contactPersonImage) {
	 * this.contactPersonImage = contactPersonImage; }
	 */
	public String getContactDescription() {
		return contactDescription;
	}
	public void setContactDescription(String contactDescription) {
		this.contactDescription = contactDescription;
	}
	

	@Override
	public boolean equals(Object obj) {
		return this.conatctId == ((UserContact)obj).getConatctId(); 
	}
	
	

}
