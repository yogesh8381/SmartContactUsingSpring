package com.contactMangement.serviceIml;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.contactMangement.model.User;
import com.contactMangement.repository.UserRepository;
import com.contactMangement.service.UserService;

@Service
public class UserServiceImp implements UserService {
	
	@Autowired
	UserRepository userRepository;

	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
	 return	userRepository.save(user);
		
	}
	
	
	public User getUserByUserName(String email) {
		return userRepository.getUserByUserName(email);
	}
	
	
	

}
