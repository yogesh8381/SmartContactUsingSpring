package com.contactMangement.serviceIml;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import com.contactMangement.model.User;
import com.contactMangement.model.UserContact;
import com.contactMangement.repository.ContactRepositoty;
import com.contactMangement.service.ContactService;

@Service
public class ContactServiceImpl implements ContactService {
	
	@Autowired
	private ContactRepositoty contactRepositoty;
	
	public  Page<UserContact> findContact(int userId, Pageable pageable) {
		
		return contactRepositoty.findContactByUser(userId, pageable);
	}
		
		
	public Optional<UserContact> showContactUsingContactId(int contactId) {
		
		
		return contactRepositoty.findById(contactId);
		
	}
	
	/*
	 * public Optional<UserContact> deleteContact(int contactId) {
	 * Optional<UserContact> contactoptinal =
	 * this.contactRepositoty.findById(contactId);
	 * 
	 * UserContact userContact = contactoptinal.get(); //check the return
	 * contactRepositoty.delete(userContact); }
	 */
	
public UserContact findByContactNameContainingAndUser(String contactName, User user){
	
	
	 return (UserContact) contactRepositoty.findByContactNameContainingAndUser(contactName, user);
	
}
	

}
